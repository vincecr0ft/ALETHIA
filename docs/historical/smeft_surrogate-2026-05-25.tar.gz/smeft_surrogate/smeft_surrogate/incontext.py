r"""
In-context Intention foundation model.
======================================

This module is the "more honest" foundation-model framing of the closed-form
``Q (K^T K + alpha I)^{-1} K^T V`` computation. Where ``model.py`` does
ordinary ridge regression with engineered features that include the Wilson
coefficients ``c``, this module does closed-form linear attention with the
Wilson coefficients LATENT: ``c`` never enters the model. The "task"
(which SMEFT theory we are in) is specified entirely by the context of
``(m_i, y_i)`` observations passed at inference time.

Why this matters
----------------

The package's ``IntentionFM`` is a function approximator: we told it the
SMEFT polynomial structure by hand-engineering ``phi_c``, then fit ridge
regression in that explicit space. It works because we encoded the answer.

This module instead treats the SAME closed-form as in-context linear
attention. The model is just the basis ``psi(m)``; everything else
(which theory, what data, what to predict) lives in the context. Two
properties follow immediately:

  * Different SMEFT scenarios share one model. New contexts give new
    predictions without any parameter update. This is what "foundation
    model" means in the in-context-learning sense.

  * The Wilson coefficients are INFERRED. Given a context of observations,
    the closed-form attention implicitly identifies which curve in the
    ``psi`` family is consistent with the data and predicts from there.
    The model never sees ``c`` as an input.

The math
--------

For a context of ``K`` observations ``(M_ctx, Y_ctx)`` and a query
``M_query``::

    Psi_ctx     = psi(M_ctx)             # (K, D_X)
    Psi_query   = psi(M_query)           # (n_q, D_X)
    A_inv       = ( Psi_ctx^T Psi_ctx + alpha I )^{-1}
    y_query     = Psi_query A_inv Psi_ctx^T Y_ctx                  # mean
    lev_query   = einsum('nd,de,ne->n', Psi_query, A_inv, Psi_query)
    sigma_query = noise_frac * |y_query| * sqrt(1 + lev_query)

This is exactly ``Q (K^T K + alpha I)^{-1} K^T V`` with ``Q = Psi_query``,
``K = Psi_ctx``, ``V = Y_ctx``. Linear attention.

Active acquisition becomes "which next observation to add to the context",
not "which next observation to fit on". The drift signal becomes
"how poorly does this context support this query", per-scenario instead
of global.

What this module does NOT do
----------------------------

It does not learn ``psi`` from data. ``psi`` is fixed to the polynomial
basis in ``log(m / M_REF)`` (the same one ``features.phi_x`` provides).
"Pretraining" in the proper FM sense would mean learning ``psi`` across
many SMEFT scenarios so the kernel ``psi(m)^T psi(m')`` captures the
right correlations. That is a future-work knob: swap in a learned basis
without changing the inference path.
"""
from __future__ import annotations

import numpy as np

from .features import phi_x, D_X, M_REF, K_X


class IntentionFMInContext:
    """
    Stateless in-context linear-attention regressor.

    There is no ``fit`` method. The "model" is the basis ``psi(m)`` and a
    handful of hyperparameters. Inference takes a CONTEXT
    ``(M_ctx, Y_ctx)`` and a QUERY ``M_query`` and runs the closed-form
    attention computation. Different contexts give different predictions;
    the model itself never changes.

    The Wilson coefficients ``c`` are not arguments anywhere. The context
    implicitly specifies them.
    """

    def __init__(self, alpha: float = 1e-3, noise_frac: float = 0.05):
        self.alpha = alpha
        self.noise_frac = noise_frac
        # Stash basis description for serialisation / inspection.
        self.basis = {"kind": "log_poly", "K_X": K_X, "M_REF": M_REF}

    # ----- core in-context prediction -----
    def predict(
        self,
        M_ctx: np.ndarray,
        Y_ctx: np.ndarray,
        M_query: np.ndarray,
        *,
        return_std: bool = True,
    ):
        """
        Closed-form attention with ``Q = psi(M_query), K = psi(M_ctx), V = Y_ctx``.

        Parameters
        ----------
        M_ctx   : (K,) array of observation m_ll values from some scenario.
        Y_ctx   : (K,) array of observed mu values at those m's.
        M_query : (n_q,) array of m_ll values to predict at, under the
                  scenario specified by the context.

        Returns
        -------
        mu       : (n_q,) predicted mean at queries.
        sigma    : (n_q,) predictive std, if ``return_std`` is True.
        """
        Psi_ctx   = phi_x(M_ctx)
        Psi_query = phi_x(M_query)
        A         = Psi_ctx.T @ Psi_ctx + self.alpha * np.eye(D_X)
        A_inv     = np.linalg.inv(A)
        mu        = Psi_query @ A_inv @ Psi_ctx.T @ Y_ctx
        if not return_std:
            return mu
        lev  = np.einsum("nd,de,ne->n", Psi_query, A_inv, Psi_query)
        aleo = (self.noise_frac * np.abs(mu)) ** 2
        return mu, np.sqrt(aleo * (1.0 + lev))

    # ----- drift signal -----
    def leverage(
        self,
        M_ctx: np.ndarray,
        M_query: np.ndarray,
    ) -> np.ndarray:
        """Per-query-point leverage in the context's feature space.

        Does not depend on ``Y_ctx``: it measures how well the context's
        observation points SUPPORT the queries, independent of the values.
        """
        Psi_ctx   = phi_x(M_ctx)
        Psi_query = phi_x(M_query)
        A_inv     = np.linalg.inv(Psi_ctx.T @ Psi_ctx + self.alpha * np.eye(D_X))
        return np.einsum("nd,de,ne->n", Psi_query, A_inv, Psi_query)

    # ----- implicit theory identification -----
    def implicit_weights(
        self,
        M_ctx: np.ndarray,
        Y_ctx: np.ndarray,
    ) -> np.ndarray:
        """Return the implicit weight vector the attention is using.

        ``w = (Psi_ctx^T Psi_ctx + alpha I)^{-1} Psi_ctx^T Y_ctx``

        This is the latent "theory representation" the model has identified
        from the context. It lives in the ``D_X``-dim basis space. For
        comparing two contexts: similar ``w`` means the contexts came from
        similar SMEFT scenarios; very different ``w`` means different
        physics.

        The model does not output the Wilson coefficients themselves; it
        outputs a latent vector that summarises the scenario the context
        belongs to.
        """
        Psi_ctx = phi_x(M_ctx)
        A_inv   = np.linalg.inv(Psi_ctx.T @ Psi_ctx + self.alpha * np.eye(D_X))
        return A_inv @ Psi_ctx.T @ Y_ctx

    # ----- context acquisition -----
    def acquire_context_extension(
        self,
        M_ctx: np.ndarray,
        M_pool: np.ndarray,
        k: int,
    ) -> np.ndarray:
        """Sherman-Morrison sequential greedy on leverage, in the context.

        Choose ``k`` indices from ``M_pool`` that, when added to the
        current context, maximally reduce predictive uncertainty about
        the same context's queries (equivalently, the natural information-
        theoretic notion of D-optimal context extension).

        Returns
        -------
        indices : (k,) array of indices into ``M_pool``.
        """
        Psi_ctx  = phi_x(M_ctx)
        Psi_pool = phi_x(M_pool)
        A_inv    = np.linalg.inv(Psi_ctx.T @ Psi_ctx + self.alpha * np.eye(D_X))
        avail    = np.ones(len(Psi_pool), dtype=bool)
        chosen: list[int] = []
        for _ in range(k):
            lev = np.einsum("nd,de,ne->n", Psi_pool, A_inv, Psi_pool)
            lev = np.where(avail, lev, -np.inf)
            i = int(np.argmax(lev))
            chosen.append(i)
            avail[i] = False
            p  = Psi_pool[i]
            Ap = A_inv @ p
            A_inv = A_inv - np.outer(Ap, Ap) / (1.0 + p @ Ap)
        return np.array(chosen)

    # ----- serialisation (trivial since model is hyperparameters only) -----
    def state_dict(self) -> dict:
        return {"alpha": self.alpha, "noise_frac": self.noise_frac, "basis": dict(self.basis)}

    @classmethod
    def from_state_dict(cls, state: dict) -> "IntentionFMInContext":
        return cls(alpha=state["alpha"], noise_frac=state["noise_frac"])
