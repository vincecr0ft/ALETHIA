# smeft_surrogate

Closed-form Intention foundation model for the SMEFT modification factor
`mu(c, m)`. The package ships **two readings of the same closed form** that
serve different purposes:

The engineered reading (`IntentionFM`) treats `Q (K^T K + αI)^-1 K^T V` as
ridge regression in a hand-engineered feature space that includes the
Wilson coefficients `c`. This is the practical surrogate: it predicts at
any `(c, m)` without needing a context, integrates simply with Phoenix
and the orchestrator, and runs the active-vs-random demos with clear
margins.

The in-context reading (`IntentionFMInContext`) treats the SAME closed
form as linear attention with the Wilson coefficients latent. The model
is just the basis `ψ(m)`; the SMEFT scenario is specified entirely by a
context of `(m_i, y_i)` observations passed at inference time. This is
the more honest foundation-model framing: one model, many scenarios,
adaptation through data not parameters.

Both expose leverage-stratified conformal calibration and three
acquisition strategies (random, leverage, EPIG). See
`docs/REFERENCE.md` § "Two readings of the same closed form" for the
relationship between them, and which to use when.

The intended use is as a fast surrogate sitting behind a Phoenix-monitored
orchestration agent (Gemini). The orchestrator reads a drift signal
(leverage on production traces), decides when to acquire new oracle points,
calls the analytic SMEFT oracle, folds the new observations in, refits the
conformal layer, and Phoenix-A/B-tests the new model version. See
`docs/INTEGRATION.md` for the wiring brief.

## Install

    pip install -e ".[plot,test]"

## Run the demos

    python scripts/demo_v3.py       # engineered FM: conformal + active vs random
    python scripts/demo_epig.py     # engineered FM: EPIG vs leverage with focused target
    python scripts/demo_incontext.py # in-context FM: one model, latent c, three scenarios

Each writes a 4-panel PNG to `/mnt/user-data/outputs/`. Headline numbers from
the included `DummyAnalyticOracle`:

    demo_v3:        active acquisition reduces hard-region mean leverage ×24
                    vs random for the same oracle budget. Conformal lifts
                    per-stratum 1σ coverage from raw 0.47–0.65 into 0.66–0.78
                    (target 0.683) without inflating the central interval.

    demo_epig:      EPIG with a focused target (a tight cloud in Wilson-mass
                    space) picks zero overlap with leverage acquisition. Mean
                    pick coordinates are pulled toward the target. Target
                    predictive variance drops 1.3–4.9× faster than leverage
                    acq on the same oracle budget.

    demo_incontext: ONE model (just the log-poly basis), three different
                    SMEFT scenarios specified entirely by context. Model
                    never sees c. Identifies each scenario from a 12-point
                    context and predicts mu(m) under it. The latent
                    implicit-weight vector w = (Psi^T Psi + αI)^-1 Psi^T Y
                    is the model's inferred theory representation; cosine
                    similarities between w vectors quantify how similar
                    two contexts' underlying theories are.

## Tests

    pytest -x -q

23 tests, ~0.5 s. Covers feature-map structure, fit/predict/update consistency,
conformal marginal and stratum coverage, acquisition uniqueness, EPIG Cauchy-
Schwarz bound, and the focused-target steering property.

## Documentation

**Read `docs/REFERENCE.md` first** if you've worked with earlier prototypes
(`intention_fm_demo.py` binned v1, `intention_fm_unbinned.py` v2) and need to
align concepts. It's the technical reference: data shapes throughout the
loop, full API contract, end-to-end worked example, mapping table from the
old binned API to this one, common pitfalls, glossary.

`docs/ARCHITECTURE.md` for the math (closed-form posterior, the SMEFT and
log-m polynomial bases, stratified split conformal, the EPIG derivation).

`docs/INTEGRATION.md` for the wiring brief: what's already in the package,
what wiring still has to happen (real oracle, OpenInference instrumentation,
Phoenix evaluators, Gemini orchestration, MCP, Cloud Run), and in what
order.

`docs/TOOLS.md` for the orchestrator-facing tool signatures Gemini will see.
