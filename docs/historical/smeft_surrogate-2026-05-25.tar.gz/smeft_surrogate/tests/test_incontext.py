import numpy as np
import pytest

from smeft_surrogate import IntentionFMInContext, DummyAnalyticOracle, N_WC


def _make_context(c_vec, n=10, seed=0, noise=True):
    oracle = DummyAnalyticOracle(seed=42)
    rng = np.random.default_rng(seed)
    M = rng.uniform(0.3, 2.3, n)
    C = np.tile(c_vec, (n, 1))
    Y = oracle(C, M, noise=noise)
    return oracle, M, Y


def test_predict_shape():
    _, M_ctx, Y_ctx = _make_context([0.5, 0.0, 0.0, 0.0])
    fm = IntentionFMInContext()
    M_q = np.linspace(0.5, 2.0, 7)
    mu, sd = fm.predict(M_ctx, Y_ctx, M_q)
    assert mu.shape == (7,)
    assert sd.shape == (7,)


def test_predict_no_std():
    _, M_ctx, Y_ctx = _make_context([0.5, 0.0, 0.0, 0.0])
    fm = IntentionFMInContext()
    M_q = np.linspace(0.5, 2.0, 7)
    mu = fm.predict(M_ctx, Y_ctx, M_q, return_std=False)
    assert mu.shape == (7,)


def test_leverage_nonneg_and_independent_of_y():
    _, M_ctx, Y_ctx_1 = _make_context([0.5, 0.0, 0.0, 0.0], seed=0)
    _, _,      Y_ctx_2 = _make_context([1.5, 0.0, 0.0, 0.0], seed=1)
    fm = IntentionFMInContext()
    M_q = np.linspace(0.5, 2.0, 7)
    # leverage depends on M_ctx only, not Y_ctx
    lev1 = fm.leverage(M_ctx, M_q)
    lev2 = fm.leverage(M_ctx, M_q)
    assert np.allclose(lev1, lev2)
    assert np.all(lev1 >= 0)


def test_different_contexts_give_different_predictions():
    """SM-like context and energy-growth context must produce different
    predictive curves at the same query points."""
    oracle, M_ctx_sm, Y_ctx_sm = _make_context([0.0, 0.0, 0.0, 0.0], seed=0, noise=False)
    _,      M_ctx_eg, Y_ctx_eg = _make_context([2.0, 0.0, 0.0, 0.0], seed=0, noise=False)
    fm = IntentionFMInContext()
    M_q = np.linspace(0.5, 2.0, 20)
    mu_sm = fm.predict(M_ctx_sm, Y_ctx_sm, M_q, return_std=False)
    mu_eg = fm.predict(M_ctx_eg, Y_ctx_eg, M_q, return_std=False)
    # The two predictive curves should differ visibly somewhere on the grid
    assert np.max(np.abs(mu_sm - mu_eg)) > 0.05


def test_implicit_weights_differ_between_scenarios():
    _, M_a, Y_a = _make_context([0.0, 0.0, 0.0, 0.0], seed=0, noise=False)
    _, M_b, Y_b = _make_context([1.5, 0.0, 0.0, 0.0], seed=0, noise=False)
    fm = IntentionFMInContext()
    w_a = fm.implicit_weights(M_a, Y_a)
    w_b = fm.implicit_weights(M_b, Y_b)
    # The latent theory representations should be visibly different
    assert np.linalg.norm(w_a - w_b) > 0.1


def test_acquire_context_extension_reduces_leverage():
    _, M_ctx, Y_ctx = _make_context([0.5, 0.0, 0.0, 0.0], n=8)
    fm = IntentionFMInContext()
    pool = np.random.default_rng(99).uniform(0.2, 2.5, 200)
    M_q  = np.linspace(0.2, 2.5, 30)
    lev_before = fm.leverage(M_ctx, M_q).mean()
    idx = fm.acquire_context_extension(M_ctx, pool, k=5)
    M_ctx_ext = np.concatenate([M_ctx, pool[idx]])
    lev_after = fm.leverage(M_ctx_ext, M_q).mean()
    assert lev_after < lev_before


def test_predict_recovers_scenario_within_noise():
    """With a noiseless 12-point context covering the m range, the model
    should recover the scenario's mu(m) curve well at interior queries."""
    oracle = DummyAnalyticOracle(seed=42)
    rng = np.random.default_rng(0)
    c_vec = np.array([0.8, 0.0, 0.0, 0.0])
    M_ctx = rng.uniform(0.3, 2.3, 12)
    C_ctx = np.tile(c_vec, (12, 1))
    Y_ctx = oracle.truth(C_ctx, M_ctx)
    fm = IntentionFMInContext()
    M_q = np.linspace(0.5, 2.0, 20)        # interior of context support
    C_q = np.tile(c_vec, (20, 1))
    mu_pred = fm.predict(M_ctx, Y_ctx, M_q, return_std=False)
    mu_true = oracle.truth(C_q, M_q)
    rel = np.abs(mu_pred - mu_true) / np.maximum(np.abs(mu_true), 1e-3)
    assert np.median(rel) < 0.05


def test_state_dict_roundtrip():
    fm = IntentionFMInContext(alpha=2e-3, noise_frac=0.07)
    s  = fm.state_dict()
    fm2 = IntentionFMInContext.from_state_dict(s)
    assert fm2.alpha      == fm.alpha
    assert fm2.noise_frac == fm.noise_frac
