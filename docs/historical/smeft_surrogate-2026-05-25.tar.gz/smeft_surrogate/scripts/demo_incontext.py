r"""
demo_incontext.py
=================

The in-context Intention foundation model in action. ONE model
(IntentionFMInContext), several SMEFT scenarios. For each scenario we
provide a CONTEXT of (m_i, y_i) observations; the model has never seen
the Wilson coefficients. It identifies the scenario from the context
and predicts at new m values under that scenario.

Three things this demonstrates:

  1. Same model, different contexts → different correct predictions.
     The model does not know which c each context came from. It infers
     the scenario implicitly from the observations and gets the curve
     right.

  2. The implicit weight vector w = (Psi^T Psi + alpha I)^-1 Psi^T Y
     differs between scenarios. This is the latent "theory
     representation" the model has identified. Similar contexts give
     similar w; different SMEFT theories give clearly different w.

  3. Context-extension acquisition: given an existing context and a
     pool of candidate m values to query the oracle at, the model
     picks the points that most reduce its predictive uncertainty in
     the same context's m range. This is per-scenario active learning.

Run: python scripts/demo_incontext.py
"""
from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt

from smeft_surrogate import (
    IntentionFMInContext, DummyAnalyticOracle,
    N_WC, M_REF,
)


# Three SMEFT scenarios. The model never sees these c values, only the
# (m, y) observations they produce.
SCENARIOS = {
    "SM-like":         np.array([ 0.0,  0.0,  0.0,  0.0]),
    "energy-growth":   np.array([+1.5,  0.0,  0.0,  0.0]),
    "interference":    np.array([+0.8, -0.8,  0.0,  0.0]),
}

CONTEXT_M_RANGE = (0.3, 2.3)
N_CONTEXT       = 12       # points per context
N_QUERY_GRID    = 200      # m values to predict at, per scenario


def main():
    oracle = DummyAnalyticOracle(seed=17)
    rng    = np.random.default_rng(2026)

    fm = IntentionFMInContext(alpha=1e-3, noise_frac=0.05)

    print("=" * 72)
    print("In-context Intention FM: one model, many scenarios, c is latent")
    print("=" * 72)
    print(f"Model state: {fm.state_dict()}")
    print(f"(There is no fit step. The model is the basis psi(m) + alpha.)")
    print()

    # Build a small context for each scenario.
    contexts: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    implicit_ws: dict[str, np.ndarray] = {}
    for name, c_vec in SCENARIOS.items():
        M_ctx = rng.uniform(*CONTEXT_M_RANGE, N_CONTEXT)
        C_ctx = np.tile(c_vec, (N_CONTEXT, 1))
        Y_ctx = oracle(C_ctx, M_ctx, noise=True)
        contexts[name] = (M_ctx, Y_ctx)
        implicit_ws[name] = fm.implicit_weights(M_ctx, Y_ctx)
        print(f"  Scenario {name!r:18s}  context size: {N_CONTEXT}  "
              f"implicit w = {implicit_ws[name].round(3).tolist()}")

    print()
    print("The implicit w vectors are the latent theory representations.")
    print("They are different because the contexts come from different physics.")

    # Verify identification by cosine similarity between implicit_w vectors.
    print()
    print("Pairwise cosine similarity of implicit theory representations:")
    names = list(SCENARIOS)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            cs = float(implicit_ws[a] @ implicit_ws[b] / (
                np.linalg.norm(implicit_ws[a]) * np.linalg.norm(implicit_ws[b])
            ))
            print(f"    {a!r:18s} vs {b!r:18s}  cos = {cs:+.3f}")

    # Evaluate at query grid: same m values, three different contexts.
    # Stay inside the context support so we see the in-context PREDICTION
    # rather than the (correct but huge) extrapolation uncertainty outside.
    M_query = np.linspace(CONTEXT_M_RANGE[0] + 0.05, CONTEXT_M_RANGE[1] - 0.05, N_QUERY_GRID)

    print()
    print(f"Predictions at {N_QUERY_GRID} m values for each context.")
    print("The model identifies each scenario implicitly and predicts the right curve.")
    print()
    print("                       median |rel err|     max leverage on query grid")
    preds = {}
    for name, (M_ctx, Y_ctx) in contexts.items():
        mu, sd = fm.predict(M_ctx, Y_ctx, M_query, return_std=True)
        # truth for THIS scenario
        c_vec = SCENARIOS[name]
        C_query = np.tile(c_vec, (len(M_query), 1))
        mu_true = oracle.truth(C_query, M_query)
        rel = np.abs(mu - mu_true) / np.maximum(np.abs(mu_true), 1e-3)
        lev = fm.leverage(M_ctx, M_query)
        print(f"  {name!r:18s}      {np.median(rel):.4f}                {lev.max():.3f}")
        preds[name] = (mu, sd, mu_true)

    # Context-extension acquisition: pick extra m points to acquire from a pool,
    # to maximally reduce predictive uncertainty within the context's m range.
    print()
    print("Context-extension acquisition (per-scenario active learning):")
    pool_M = rng.uniform(0.2, 2.5, 300)
    for name, (M_ctx, Y_ctx) in contexts.items():
        idx_add = fm.acquire_context_extension(M_ctx, pool_M, k=5)
        added   = pool_M[idx_add]
        # Compute leverage on query grid BEFORE and AFTER adding the new points
        lev_before = fm.leverage(M_ctx, M_query).mean()
        M_ctx_ext  = np.concatenate([M_ctx, added])
        lev_after  = fm.leverage(M_ctx_ext, M_query).mean()
        print(f"  {name!r:18s}  added m = {added.round(2).tolist()}")
        print(f"  {'':20s}  mean query-grid leverage:  {lev_before:.3f}  ->  {lev_after:.3f}  "
              f"(×{lev_before/lev_after:.1f} reduction)")

    # ------- plot: deviation from SM (mu - 1) is the physically meaningful signal -------
    fig, axes = plt.subplots(1, len(SCENARIOS), figsize=(15, 4.8),
                             constrained_layout=True, sharey=True)
    for ax, (name, (M_ctx, Y_ctx)) in zip(axes, contexts.items()):
        mu, sd, mu_true = preds[name]
        ax.axhline(0.0, color="gray", lw=0.6, alpha=0.6)
        ax.plot(M_query, mu_true - 1.0, "k-", lw=1.5, label="true mu - 1 (oracle)")
        ax.plot(M_query, mu      - 1.0, "C3-", lw=1.2, label="in-context attention")
        ax.fill_between(M_query, mu - 1.0 - sd, mu - 1.0 + sd, color="C3", alpha=0.22,
                        label="predictive 1σ")
        ax.scatter(M_ctx, Y_ctx - 1.0, c="C0", s=24, zorder=3,
                   edgecolors="black", lw=0.4, label=f"context (K={N_CONTEXT})")
        c_vec = SCENARIOS[name]
        ax.set_title(f"scenario: {name}\nhidden c = {c_vec.tolist()}")
        ax.set_xlabel(r"$m_{\ell\ell}$ / TeV")
        ax.grid(alpha=0.3)
        if ax is axes[0]:
            ax.set_ylabel(r"$\mu - 1$  (deviation from SM)")
        ax.legend(fontsize=7, loc="best")

    fig.suptitle("In-context Intention FM: one model, three contexts, three theories\n"
                 "The model never sees c. Each prediction emerges from its context.",
                 fontsize=11)
    out = "/mnt/user-data/outputs/demo_incontext.png"
    fig.savefig(out, dpi=130)
    print(f"\nSaved plot to {out}")


if __name__ == "__main__":
    main()
